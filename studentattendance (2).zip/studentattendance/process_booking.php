<?php
// Process the selected seat data received from JavaScript
$data = json_decode(file_get_contents("php://input"), true);

// Perform server-side validation and calculation
if (!empty($data['selectedSeats'])) {
    $seatPrice = 10;
    $totalAmount = count($data['selectedSeats']) * $seatPrice;

    // Send a JSON response back to JavaScript
    $response = [
        'success' => true,
        'amount' => $totalAmount
    ];
} else {
    $response = [
        'success' => false,
        'message' => 'No seats selected.'
    ];
}

header('Content-Type: application/json');
echo json_encode($response);
?>
