<?php
else if ($userType == "Student") {
    $query = "SELECT * FROM tblstudent WHERE emailAddress = '$username' AND password = '$password'";
    $rs = $conn->query($query);
    $num = $rs->num_rows;
    $rows = $rs->fetch_assoc();

    if ($num > 0) {
        $_SESSION['userId'] = $rows['Id'];
        $_SESSION['firstName'] = $rows['firstName'];
        $_SESSION['lastName'] = $rows['lastName'];
        $_SESSION['emailAddress'] = $rows['emailAddress'];
        // Add any additional session variables you need for the student

        echo "<script type = \"text/javascript\">
        window.location = (\"Student/index.php\")
        </script>";
    } else {
        echo "<div class='alert alert-danger' role='alert'>
        Invalid Username/Password!
        </div>";
    }
}

?>