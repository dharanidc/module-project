<?php

$conn = mysqli_connect('localhost','root','','attendance') or die('connection failed');

?>